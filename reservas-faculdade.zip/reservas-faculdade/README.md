# Reservas da Faculdade

Sistema de reserva de salas, laboratórios e equipamentos, feito para demonstrar Docker, ECR, ECS/Fargate, ALB e CloudFormation no AWS Learner Lab. 

## Como as peças se encaixam

```
navegador ──► ALB ──┬─ /api/usuarios/*  ──► usuarios  (3001)  login e JWT
                    ├─ /api/recursos/*  ──► recursos  (3002)  catálogo
                    ├─ /api/reservas/*  ──► reservas   (3003)  agenda + regra de conflito ──► SQS ──► notificacoes (worker)
                    └─ (qualquer outro) ──► web        (8080)  interface
                                   cada serviço ──► PostgreSQL (RDS), um esquema e um usuário de banco por serviço
```


## Estrutura

```
docker-compose.yml        PostgreSQL + serviços + nginx ("ALB" local em :8000)
.env.example
servicos/
  usuarios/               Django + DRF — cadastro, login, emissão do JWT
  recursos/               Django + DRF — catálogo (leitura pública, escrita só admin)
  reservas/               Django + DRF — agenda; agenda/regras.py (regras puras), eventos.py (SQS)
  web/                    Django com templates e JS puro, sem banco
  notificacoes/           worker.py (long polling do SQS), sem Django
infra/
  ecr.yaml                stack reserva-ecr: 6 repositórios
  dados.yaml              stack reserva-dados: RDS PostgreSQL, security group do banco, fila SQS + DLQ
  app.yaml                stack reserva-app: cluster, ALB, target groups, task definitions, services
  bootstrap/              bootstrap.sql + Dockerfile (imagem "migracao")
  local/                  nginx.conf e proxy.py (ALB local, com e sem Docker)
scripts/
  build-push.sh           build e push das 6 imagens para o ECR
  migrar.sh               bootstrap + migrations/seed no RDS, via ecs run-task
  teste_integracao.py     teste ponta a ponta (inclui a disputa pelo mesmo horário)
  demo/                   concorrencia.sh, loop-alb.sh
```



## Implantação na AWS (Learner Lab): passo a passo

Subir o sistema leva de 30 a 45 minutos (estimativa), em sua maior parte esperando o banco e a construção das
imagens. Tudo roda no **CloudShell** do Learner Lab. São três stacks, em camadas, com ciclos de vida
diferentes, e a ordem importa: `reserva-ecr` (repositórios), `reserva-dados` (banco e fila) e
`reserva-app` (aplicação, descartável).

### Antes de começar

- Learner Lab iniciado (indicador verde no AWS Academy) e o console da AWS aberto.
- O `reservas-faculdade.zip` deste projeto.
- Dois valores que você escolhe agora e usa de novo no passo 4. Anote os dois:
  - `DbSenha`: senha do banco, só letras e números, no mínimo 8 caracteres (exemplo: `SenhaDb2026`). Precisa
    ser a **mesma** nas stacks `reserva-dados` e `reserva-app`.
  - `JwtSecret`: segredo do login, no mínimo 8 caracteres (exemplo: `SegredoJwt2026`).

Os exemplos usam a região `us-east-1`. Se o console mostrar outra, troque nos comandos.

### 1. Preparar o CloudShell

1. No console, clique no ícone do CloudShell (`>_`) na barra superior e espere o terminal abrir.
2. Clique em **Actions → Upload file** e envie o zip.
3. Rode:

```bash
unzip reservas-faculdade.zip && cd reservas-faculdade
chmod +x scripts/*.sh scripts/demo/*.sh
export AWS_REGION=us-east-1
aws sts get-caller-identity                       # deve mostrar o número da conta
docker version --format '{{.Server.Version}}'     # deve mostrar a versão do Docker
```

O CloudShell fecha a sessão após 20 a 30 minutos sem uso. A pasta continua lá, mas **as variáveis do terminal
se perdem** (`AWS_REGION`, `VPC`, `SUBNETS`, `ARQ`). Se reabrir o terminal, refaça os comandos que as definem.

### 2. Repositórios e imagens

As imagens saem na arquitetura da máquina que as constrói, e a stack da aplicação precisa usar a mesma, senão
as tasks falham com `exec format error`. Descubra a sua e guarde o valor:

```bash
ARQ=$([ "$(uname -m)" = aarch64 ] && echo ARM64 || echo X86_64)
echo $ARQ                                         # X86_64 ou ARM64
```

Crie os repositórios e envie as 6 imagens, uma por vez (o laço limpa o disco entre elas, porque o CloudShell
tem pouco espaço):

```bash
aws cloudformation deploy --stack-name reserva-ecr --template-file infra/ecr.yaml

for s in usuarios recursos reservas web notificacoes migracao; do
  scripts/build-push.sh $s v1 || break
  docker image prune -af > /dev/null
done

aws ecr describe-images --repository-name reserva-reservas --query 'imageDetails[].imageTags'   # deve mostrar v1
```

Se aparecer `no space left on device`, rode `docker system prune -af` e repita só o serviço que falhou.

### 3. Rede, banco e fila

O comando escolhe sozinho a VPC padrão e duas subnets de zonas diferentes:

```bash
VPC=$(aws ec2 describe-vpcs --filters Name=isDefault,Values=true --query 'Vpcs[0].VpcId' --output text)
SUBNETS=$(aws ec2 describe-subnets --filters Name=vpc-id,Values=$VPC Name=default-for-az,Values=true \
  --query 'Subnets[].[AvailabilityZone,SubnetId]' --output text | sort -u -k1,1 | head -2 | awk '{print $2}' | paste -sd,)
echo "VPC=$VPC"; echo "SUBNETS=$SUBNETS"
```

Confira: `VPC` começa com `vpc-` e `SUBNETS` tem duas subnets reais separadas por vírgula. Nunca use valores de exemplo (`subnet-aaaa`) nem deixe as variáveis vazias: a stack falha na validação.

```bash
aws cloudformation deploy --stack-name reserva-dados --template-file infra/dados.yaml \
  --parameter-overrides VpcId=$VPC Subnets=$SUBNETS DbSenha='SenhaDb2026'
```

O RDS leva de 5 a 10 minutos. Espere o comando terminar. 

### 4. Aplicação

Cria o cluster, o ALB e os 5 serviços. Use a **mesma** `DbSenha` do passo 3. As imagens do passo 2 precisam estar no ECR.

```bash
echo "VPC=$VPC"; echo "SUBNETS=$SUBNETS"; echo "ARQ=$ARQ"     # nenhum pode estar vazio

aws cloudformation deploy --stack-name reserva-app --template-file infra/app.yaml \
  --parameter-overrides VpcId=$VPC Subnets=$SUBNETS DbSenha='SenhaDb2026' JwtSecret='SegredoJwt2026' Arquitetura=$ARQ
```

### 5. Preparar o banco

O banco novo não tem esquemas nem usuários. O script cria a extensão, os esquemas e os usuários, e aplica as migrations e os dados de exemplo (4 tarefas em sequência, com os logs de cada uma):

```bash
scripts/migrar.sh
```

Termina com `Banco pronto.` Pode ser repetido sem problema. Se a stack `reserva-app` não estiver pronta (por exemplo, em `ROLLBACK_COMPLETE`), o script avisa logo no início. Enquanto o banco não é preparado, os `/health` passam e as chamadas de dados respondem `503`: isso é esperado.

### 6. Testar e usar

```bash
ALB=$(aws cloudformation describe-stacks --stack-name reserva-app \
  --query "Stacks[0].Outputs[?OutputKey=='AlbUrl'].OutputValue" --output text)
echo $ALB
curl -s -o /dev/null -w "%{http_code}\n" $ALB/api/recursos/       # 200
BASE_URL=$ALB python3 scripts/teste_integracao.py
```

Se aparecer `502` ou `503` logo após o deploy, espere cerca de 1 minuto. Abra o endereço no navegador, **com `http://`** (não há HTTPS), e entre com uma das contas do seed 

### Ações da demonstração

Todas viram uma atualização da stack `reserva-app`. Repita `VpcId`, `Subnets`, `DbSenha`, `JwtSecret` e `Arquitetura` junto com o parâmetro novo.

| Demonstração | Parâmetro |
|---|---|
| Escalar reservas | `QtdReservas=3` |
| Rolling deployment | `scripts/build-push.sh reservas v2` e depois `TagReservas=v2` |
| Circuit breaker | `QUEBRAR_HEALTH=1 scripts/build-push.sh reservas v3` e depois `TagReservas=v3`: o deploy falha e volta para a v2 |
| Mudar uma regra de negócio | `DuracaoMaxHoras=2` (novo deploy de reservas) |
| Economizar | `QtdPadrao=0 QtdReservas=0 QtdNotificacoes=0` (o RDS continua) |

### Pausar e retomar entre sessões

Fechar o laboratório não garante que os serviços parem. Deixar tudo ligado custa cerca de US$ 0,10 por hora (estimativa pelos preços de lista de us-east-1; o saldo real está no painel do Learner Lab). Para pausar:

```bash
for s in web usuarios recursos reservas notificacoes; do
  aws ecs update-service --cluster reserva --service $s --desired-count 0 > /dev/null
done
DB=$(aws rds describe-db-instances --query 'DBInstances[?contains(DBInstanceIdentifier,`reserva`)].DBInstanceIdentifier' --output text)
aws rds stop-db-instance --db-instance-identifier $DB
```

Para retomar:

```bash
DB=$(aws rds describe-db-instances --query 'DBInstances[?contains(DBInstanceIdentifier,`reserva`)].DBInstanceIdentifier' --output text)
aws rds start-db-instance --db-instance-identifier $DB
aws rds wait db-instance-available --db-instance-identifier $DB
for s in web usuarios recursos reservas notificacoes; do
  aws ecs update-service --cluster reserva --service $s --desired-count 1 > /dev/null
done
```

O endereço do ALB não muda e os dados continuam no banco. O ALB continua cobrando mesmo pausado, e um RDS parado por 7 dias é religado automaticamente pela AWS. Não use a opção *Reset* do laboratório, que costuma apagar os recursos da conta.

### Problemas comuns

| Sintoma | O que fazer |
|---|---|
| Stack em `ROLLBACK_COMPLETE` | Não pode ser atualizada. Veja a causa nos eventos (abaixo), apague a stack e crie de novo. |
| `parameter value  for parameter name Subnets does not exist` (valor vazio ou de exemplo) | As variáveis `VPC` e `SUBNETS` estavam vazias. Refaça o passo 3 e confira o `echo` antes do `deploy`. |
| `exec format error` na task | A arquitetura das tasks difere da das imagens. Atualize a stack com `Arquitetura` igual ao `uname -m` (`aarch64` = `ARM64`, `x86_64` = `X86_64`). |
| `TaskDefinition not found` no `migrar.sh` | A stack `reserva-app` não está pronta ou a região é outra. Confira `AWS_REGION` e o status da stack. |
| O site não abre | Use `http://`, espere 1 a 2 minutos e confira se `running` é igual a `desired` nos services. |
| `503` com `banco_indisponivel` | Rode `scripts/migrar.sh` e confira se a `DbSenha` é a mesma nas duas stacks. |
| `no space left on device` no build | `docker system prune -af` e repita só o serviço que falhou. |

```bash
# eventos da stack (a causa costuma estar no CREATE_FAILED mais antigo)
aws cloudformation describe-stack-events --stack-name reserva-app --output text \
  --query 'StackEvents[].[Timestamp,LogicalResourceId,ResourceStatus,ResourceStatusReason]'

# services e logs
aws ecs describe-services --cluster reserva --services web usuarios recursos reservas notificacoes \
  --query 'services[].[serviceName,desiredCount,runningCount]' --output text
aws logs tail /ecs/reserva --since 10m

# apagar uma stack falhada
aws cloudformation delete-stack --stack-name reserva-app
aws cloudformation wait stack-delete-complete --stack-name reserva-app
```

### Apagar tudo no fim

Nesta ordem, esperando cada uma terminar (a aplicação depende do banco):

```bash
aws cloudformation delete-stack --stack-name reserva-app
aws cloudformation wait stack-delete-complete --stack-name reserva-app
aws cloudformation delete-stack --stack-name reserva-dados
aws cloudformation wait stack-delete-complete --stack-name reserva-dados
aws cloudformation delete-stack --stack-name reserva-ecr
```

Isso apaga o banco (sem cópia de segurança), a fila e as imagens.



